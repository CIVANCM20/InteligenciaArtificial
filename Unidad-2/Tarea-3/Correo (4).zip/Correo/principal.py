import tkinter as tk
from tkinter import scrolledtext, messagebox
import pandas as pd
import re

def crear_interfaz():
    ventana = tk.Tk()
    ventana.title("Correando")
    ventana.geometry("800x600")
    
    ventana.grid_rowconfigure(0, weight=1)
    ventana.grid_rowconfigure(1, weight=10)
    ventana.grid_rowconfigure(2, weight=1)
    ventana.grid_rowconfigure(3, weight=10)
    ventana.grid_rowconfigure(4, weight=1)
    ventana.grid_columnconfigure(0, weight=1)

    secciones = []

    # SECCIÓN PARA INSERTAR NUEVOS MENSAJES
    # Categoría
    frame_categoria = tk.Frame(ventana, bd=1, relief=tk.SUNKEN)
    frame_categoria.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
    lbl_categoria = tk.Label(frame_categoria, text="Categoría (spam/ham):", anchor="w")
    lbl_categoria.pack(fill=tk.X)
    editor_categoria = tk.Text(frame_categoria, wrap=tk.WORD, width=80, height=1, font=("Arial", 11), padx=5, pady=5)
    editor_categoria.pack(expand=True, fill="both")
    secciones.append(editor_categoria)

    # Autor
    frame_autor = tk.Frame(ventana, bd=1, relief=tk.SUNKEN)
    frame_autor.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
    lbl_autor = tk.Label(frame_autor, text="Autor:", anchor="w")
    lbl_autor.pack(fill=tk.X)
    editor_autor = tk.Text(frame_autor, wrap=tk.WORD, width=80, height=1, font=("Arial", 11), padx=5, pady=5)
    editor_autor.pack(expand=True, fill="both")
    secciones.append(editor_autor)
    
    # Asunto
    frame_asunto = tk.Frame(ventana, bd=1, relief=tk.SUNKEN)
    frame_asunto.grid(row=2, column=0, sticky="nsew", padx=5, pady=5)
    lbl_asunto = tk.Label(frame_asunto, text="Asunto:", anchor="w")
    lbl_asunto.pack(fill=tk.X)
    editor_asunto = tk.Text(frame_asunto, wrap=tk.WORD, width=80, height=1, font=("Arial", 11), padx=5, pady=5)
    editor_asunto.pack(expand=True, fill="both")
    secciones.append(editor_asunto)
    
    # Mensaje
    frame_mensaje = tk.Frame(ventana, bd=1, relief=tk.SUNKEN)
    frame_mensaje.grid(row=3, column=0, sticky="nsew", padx=5, pady=5)
    lbl_mensaje = tk.Label(frame_mensaje, text="Mensaje:", anchor="w")
    lbl_mensaje.pack(fill=tk.X)
    editor_mensaje = scrolledtext.ScrolledText(frame_mensaje, wrap=tk.WORD, width=80, height=5, font=("Arial", 11), padx=5, pady=5)
    editor_mensaje.pack(expand=True, fill="both")
    secciones.append(editor_mensaje)
    
    # Función para guardar el nuevo mensaje
    def guardar_nuevo_mensaje():

        categoria = editor_categoria.get("1.0", "end-1c").strip()
        autor = editor_autor.get("1.0", "end-1c").strip()
        asunto = editor_asunto.get("1.0", "end-1c").strip()
        mensaje = editor_mensaje.get("1.0", "end-1c").strip()

        if not categoria or not autor or not asunto or not mensaje:
            messagebox.showerror("Error", "Por favor, completa todos los campos.")
            return

        # Guardar el mensaje en el archivo CSV
        try:
            nuevo_mensaje = pd.DataFrame({
                'Category': [categoria],
                'Author': [autor],
                'Subject': [asunto],
                'Message': [mensaje]
            })
            nuevo_mensaje.to_csv('mail_data.csv', mode='a', index=False, header=False)
            messagebox.showinfo("Éxito", "El nuevo mensaje se guardó correctamente.")
            
            editor_categoria.delete("1.0", "end")
            editor_autor.delete("1.0", "end")
            editor_asunto.delete("1.0", "end")
            editor_mensaje.delete("1.0", "end")
        except Exception as e:
            messagebox.showerror("Error", f"Error al guardar el mensaje: {e}")

    # Botón para guardar el nuevo mensaje
    btn_guardar = tk.Button(ventana, text="Guardar Nuevo Mensaje", command=guardar_nuevo_mensaje)
    btn_guardar.grid(row=4, column=0, pady=5)

    # Listbox con desplazador para correos
    frame_lista = tk.Frame(ventana, bd=1, relief=tk.SUNKEN)
    frame_lista.grid(row=5, column=0, sticky="nsew", padx=5, pady=5)
    scrollbar = tk.Scrollbar(frame_lista)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
    listbox = tk.Listbox(frame_lista, yscrollcommand=scrollbar.set, font=("Arial", 11))
    listbox.pack(expand=True, fill="both")
    scrollbar.config(command=listbox.yview)
    
    # Función para escanear correos
    def escanear_correos():
        try:
            
            df = pd.read_csv('mail_data.csv')
            
            #
            if {'Category', 'Author', 'Subject', 'Message'}.issubset(df.columns):
                correos = df[['Category', 'Author', 'Subject', 'Message']].dropna()
                listbox.delete(0, tk.END)  
                
                # Iterar sobre los correos y llenar el Listbox
                for index, row in correos.iterrows():
                    categoria = row['Category']
                    autor = row['Author']
                    asunto = row['Subject']
                    mensaje = row['Message'].lower()  
                    listbox.insert(tk.END, f"Categoria: {categoria} | Autor: {autor} | Asunto: {asunto} | Mensaje: {mensaje}")
            else:
                messagebox.showerror("Error", "El archivo CSV debe contener las columnas 'Category', 'Author', 'Subject' y 'Message'")
        except Exception as e:
            messagebox.showerror("Error", f"Error al leer el archivo CSV: {e}")

    # Función para aplicar las reglas al correo seleccionado
    def aplicar_codigo():
        try:
            # Obtener el elemento seleccionado
            seleccion = listbox.curselection()
            if seleccion:
                # Separar los datos para analizar correctamente el mensaje
                contenido = listbox.get(seleccion[0])
                partes = contenido.split(" | ")
                categoria = partes[0].split(": ")[1]
                autor = partes[1].split(": ")[1]
                asunto = partes[2].split(": ")[1]
                mensaje = partes[3].split(": ")[1]

                # Verificar autor
                amigos = importar_excel('amigos')
                resultado_autor = "El autor está en la lista de amigos" if autor in amigos else "El autor NO está en la lista de amigos"

                # Verificar enlaces maliciosos
                resultado_malware = verificar_enlaces_maliciosos(mensaje)

                # Verificar asunto sospechoso
                resultado_asunto = verificar_asunto_demasiado_bueno(asunto)

                # Verificar palabras baneadas
                resultado_baneadas = comprobarPalabra(mensaje)

                # Determinar clasificación 
                if "NO está en la lista de amigos" in resultado_autor or \
                "Contiene enlace malicioso" in resultado_malware or \
                "Contiene asunto sospechoso" in resultado_asunto or \
                "Palabra Baneada" in resultado_baneadas:
                    clasificacion = "El mensaje es SPAM"
                else:
                    clasificacion = "El mensaje NO es SPAM"

                # Mostrar resultados
                messagebox.showinfo(
                    "Resultado",
                    f"Categoría original: {categoria}\n"
                    f"{resultado_autor}\n{resultado_malware}\n{resultado_asunto}\n{resultado_baneadas}\n\n"
                    f"Clasificación final: {clasificacion}"
                )
            else:
                messagebox.showerror("Error", "Por favor selecciona un mensaje")
        except Exception as e:
            messagebox.showerror("Error", f"Error al ejecutar el código: {e}")



    
    def verificar_enlaces_maliciosos(mensaje):
        # Lista de sitios maliciosos conocidos
        sitios_maliciosos = ["malware-site.com", "badlink.net", "phishing-example.org"]

        # Buscar enlaces en el mensaje
        enlaces = re.findall(r'(https?://[^\s]+)', mensaje)
        for enlace in enlaces:
            dominio = enlace.split('/')[2].lower()  
            if dominio in sitios_maliciosos:
                return f"Contiene enlace malicioso: {enlace}"

        
        palabras = mensaje.lower().split() 
        for sitio in sitios_maliciosos:
            if sitio in palabras:
                return f"Contiene referencia directa a un sitio malicioso: {sitio}"

        return "No contiene enlace a sitios maliciosos"

    def verificar_asunto_demasiado_bueno(mensaje):
        palabras_clave = [
        "win", "free", "exclusive offer", "prize", 
        "you have won", "easy money", "unique offer", 
        "get rich", "today only", "free trip", 
        "gift", "millions", "congratulations", "approved"
    ]
        mensaje_lower = mensaje.lower()
        for palabra in palabras_clave:
            if palabra in mensaje_lower:
                return f"Contiene asunto sospechoso: {palabra}"
        return "El asunto parece normal"
    
    # Botones
    btn_escanear = tk.Button(ventana, text="Escanear Correos", command=escanear_correos)
    btn_escanear.grid(row=6, column=-0, pady=5)
    
    btn_aplicar_codigo = tk.Button(ventana, text="Aplicar Reglas", command=aplicar_codigo)
    btn_aplicar_codigo.grid(row=7, column=0, pady=5)
    
    ventana.mainloop()

def comprobarPalabra(mensaje):
    palabrasMensaje = mensaje.split()
    palabraBaneadas = importar_excel('palabras_baneadas')  
    for cadaPM in palabrasMensaje:
        if cadaPM in palabraBaneadas:
            return "Palabra Baneada" 
    return "No tiene palabra baneada"  


def importar_excel(columna):
    df = pd.read_csv('correoDatos.csv')
    datos = df[columna].dropna().tolist()
    return datos

if __name__ == "__main__":
    crear_interfaz()
