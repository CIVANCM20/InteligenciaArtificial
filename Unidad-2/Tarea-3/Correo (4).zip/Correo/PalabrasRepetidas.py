import pandas as pd
from collections import Counter
import re

def get_most_common_spam_words(csv_path, n_words=30, custom_stopwords=None):
    """
    Analiza un archivo CSV y devuelve las palabras más comunes en mensajes spam (target=1)
    excluyendo palabras comunes en inglés.
    
    Args:
        csv_path (str): Ruta al archivo CSV
        n_words (int): Número de palabras más comunes a devolver
        custom_stopwords (list): Lista adicional de palabras a excluir
    
    Returns:
        DataFrame: Palabras más comunes y sus frecuencias
    """
    
    # Lista de palabras comunes en inglés a excluir (stop words)
    english_stopwords = {
        'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your', 
        'yours', 'yourself', 'yourselves', 'he', 'him', 'his', 'himself', 'she', 
        'her', 'hers', 'herself', 'it', 'its', 'itself', 'they', 'them', 'their', 
        'theirs', 'themselves', 'what', 'which', 'who', 'whom', 'this', 'that', 
        'these', 'those', 'am', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 
        'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'a', 'an', 
        'the', 'and', 'but', 'if', 'or', 'because', 'as', 'until', 'while', 'of', 
        'at', 'by', 'for', 'with', 'about', 'against', 'between', 'into', 'through', 
        'during', 'before', 'after', 'above', 'below', 'to', 'from', 'up', 'down', 
        'in', 'out', 'on', 'off', 'over', 'under', 'again', 'further', 'then', 
        'once', 'here', 'there', 'when', 'where', 'why', 'how', 'all', 'any', 
        'both', 'each', 'few', 'more', 'most', 'other', 'some', 'such', 'no', 
        'nor', 'not', 'only', 'own', 'same', 'so', 'than', 'too', 'very', 'can', 
        'will', 'just', 'don', 'should', 'now',
        
        'html', 'head', 'title', 'body', 'div', 'span', 'p', 'br', 'hr', 'h1', 'h2', 'h3', 'h4', 'h5', 
        'h6', 'header', 'footer', 'nav', 'section', 'article', 'aside', 'main', 'strong', 'em', 'b', 'i',
        'u', 'mark', 'small', 'sub', 'sup', 'ul', 'ol', 'li', 'dl', 'dt', 'dd', 'table', 'tr', 'td', 'th',
        'thead', 'tbody', 'tfoot', 'caption', 'form', 'input', 'textarea', 'button', 'select', 'option',
        'label', 'fieldset', 'legend', 'datalist', 'output', 'img', 'audio', 'video', 'source', 'track',
        'picture', 'figure', 'figcaption', 'a', 'link', 'nav', 'map', 'area', 'meta', 'style', 'script',
        'noscript', 'class', 'id', 'style', 'href', 'src', 'alt', 'width', 'height', 'type', 'value', 
        'name', 'placeholder', 'required', 'disabled', 'target', 'rel', 'charset', 'lang', 'colspan', 
        'rowspan', 'canvas', 'svg', 'progress', 'meter', 'details', 'summary', 'time', 'onclick', 
        'onload', 'onchange', 'onsubmit', 'onmouseover', 'onkeydown', 'iframe', 'embed', 'object', 
        'param', 'base', 'DOCTYPE', 'comment', 'template', 'slot', 'shadow', 'dialog', 'menu', 
        'menuitem'
    }
    
    # Combinar stopwords predeterminadas con las personalizadas
    if custom_stopwords:
        english_stopwords.update(custom_stopwords)
    
    # Leer el archivo CSV
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        print(f"Error al leer el archivo CSV: {e}")
        return None
    
    # Verificar que existan las columnas necesarias
    if 'text' not in df.columns or 'target' not in df.columns:
        print("El archivo CSV debe contener las columnas 'text' y 'target'")
        return None
    
    # Filtrar solo los mensajes spam (target = 1)
    spam_messages = df[df['target'] == 1]['text']
    
    # Procesar el texto y contar palabras
    word_counter = Counter()
    
    for message in spam_messages:
        if pd.isna(message):
            continue
            
        # Convertir a minúsculas y eliminar caracteres no alfabéticos
        words = re.findall(r'\b[a-z]+\b', message.lower())
        # Filtrar stopwords y palabras muy cortas
        filtered_words = [word for word in words 
                         if word not in english_stopwords and len(word) > 2]
        word_counter.update(filtered_words)
    
    # Obtener las n palabras más comunes
    most_common = word_counter.most_common(n_words)
    
    # Crear un DataFrame con los resultados
    result_df = pd.DataFrame(most_common, columns=['Palabra', 'Frecuencia'])
    
    return result_df

# Ejemplo de uso
if __name__ == "__main__":
    # Puedes añadir palabras adicionales para excluir
    custom_exclusions = ['www', 'http', 'com', 'html', 'subject', 'nbsp', 'click', 'please']
    
    # Reemplaza 'spam_data.csv' con la ruta a tu archivo
    result = get_most_common_spam_words('spam_assassin.csv', custom_stopwords=custom_exclusions)
    
    if result is not None:
        print("\nPalabras más comunes en mensajes spam:")
        print(result)
        